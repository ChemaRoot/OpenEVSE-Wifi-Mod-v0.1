#ifndef _EMONESP_OHM_H
#define _EMONESP_OHM_H

#include <Arduino.h>

extern String ohm_hour;

extern void ohm_loop();
#endif // _EMONESP_OHM_H
