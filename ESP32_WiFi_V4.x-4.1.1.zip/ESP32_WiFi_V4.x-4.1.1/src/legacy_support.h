#ifndef LEGACY_SUPPORT_H
#define LEGACY_SUPPORT_H

#include "scheduler.h"

void import_timers(Scheduler *scheduler);

#endif // !LEGACY_SUPPORT_H
