static const char CONTENT_TERM_HTML[] PROGMEM = 
  "<html> <head> <title>OpenEVSE Terminal</title> <style> body {\n"
  "      color:#fff;\n"
  "      background-color:#300a24;\n"
  "    }\n"
  "    pre {\n"
  "      word-break: break-all;\n"
  "      white-space: pre-wrap;\n"
  "    } </style> <script src=\"term.js\"></script> </head> <body> <pre id=\"term\"></pre> </body> </html>\n";
static const char CONTENT_TERM_HTML_ETAG[] PROGMEM = "9bd77665eb816544b67953669f1b762d55d5675616a9462c8ad6ae2f04bd4cec";
