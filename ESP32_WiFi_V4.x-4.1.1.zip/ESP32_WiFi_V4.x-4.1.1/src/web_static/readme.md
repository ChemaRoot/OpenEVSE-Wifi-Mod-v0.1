# Note #

Do not edit these files, these are all auto generated from the files in `gui`.

To update do the following:

1. Make sure the content of `gui` is up-to-date

    ```shell
    cd gui
    git checkout master
    git pull
    ```

2. 'Build' the UI

    ```shell
    npm install
    npm run build
    ```

3. Build/Upload the project as normal
