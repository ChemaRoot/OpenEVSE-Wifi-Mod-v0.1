#ifndef _OPENEVSE_ROOT_CA_H
#define _OPENEVSE_ROOT_CA_H

extern const char *root_ca;

#endif
