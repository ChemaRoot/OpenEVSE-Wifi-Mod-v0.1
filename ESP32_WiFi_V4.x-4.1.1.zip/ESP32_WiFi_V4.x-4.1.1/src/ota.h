#ifndef _EMONESP_OTA_H
#define _EMONESP_OTA_H

// -------------------------------------------------------------------
// Support for updating the fitmware os the ESP8266
// -------------------------------------------------------------------

#include <Arduino.h>

void ota_setup();
void ota_loop();

#endif // _EMONESP_OTA_H
